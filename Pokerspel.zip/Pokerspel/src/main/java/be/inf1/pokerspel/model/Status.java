/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package be.inf1.pokerspel.model;

/**
 *
 * @author Jasper
 */
public enum Status {
    NIKS, EEN_KAART, called,fold,raised,checked,speler_wint,bot_wint,gelijkspel, niet_bepaald
}

